const apiKey = '5279dc4d5c8a04b759eab61320a6c44b';

async function getWeatherData(city) {
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

  try {
    const response = await fetch(url);
    const data = await response.json();
    return data;
  } catch (error) {
    console.log('Error:', error);
  }
}

function displayWeatherInfo(city, weatherData) {
  const weatherInfo = document.getElementById('weatherInfo');

  // Clear previous weather information
  weatherInfo.innerHTML = '';

  if (weatherData.cod === '404') {
    weatherInfo.textContent = `No weather information found for ${city}`;
  } else {
    const cityName = weatherData.name;
    const temperature = weatherData.main?.temp;
    const description = weatherData.weather[0]?.description;
    const tempMin = weatherData.main?.temp_min;
    const tempMax = weatherData.main?.temp_max;

    console.log(weatherData);

    if (temperature === undefined || description === undefined || tempMin === undefined || tempMax === undefined) {
      console.log('Error: Invalid weather data');
      return;
    }

    const currentDate = new Date();
    const options = { weekday: 'long', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric' };
    const dateTimeString = currentDate.toLocaleString('en-US', options);

    const weatherHtml = `
      <h2>${cityName}</h2>
      <p class="datetime">${dateTimeString}</p>
      <p class="temperature">${temperature} &#8451;</p>
      <p class="description">${description}</p>
      <p class="temp-range">${tempMin} &#8451;/${tempMax} &#8451;</p>
    `;

    weatherInfo.innerHTML = weatherHtml;
  }
}

function handleFormSubmit(event) {
  event.preventDefault();
  const cityInput = document.getElementById('cityInput');
  const city = cityInput.value.trim();

  if (city !== '') {
    getWeatherData(city)
      .then(data => displayWeatherInfo(city, data))
      .catch(error => console.log('Error:', error));

    cityInput.value = '';
  }
}

const cityForm = document.getElementById('cityForm');
cityForm.addEventListener('submit', handleFormSubmit);
